	<div id="footer">
	Powered by <a href="http://www.wordpress.org">Wordpress</a> - Design by <a href="http://www.designer-daily.com">Designer-daily</a>
	</div>
	</div>
</body>
</html>